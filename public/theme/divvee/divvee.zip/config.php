<?php 
$explode_uri = explode("/",dirname($_SERVER['PHP_SELF'])); 
$link = 'http://localhost'.dirname($_SERVER['PHP_SELF']) . '/';
if(in_array('cp',$explode_uri))
{
	$implode = implode("/",$explode_uri); 
	$test = str_replace("/cp","",$implode);
	$link = 'http://localhost'.$test."/";  
}

define('BASE', $link); 
define('BASE_IMG', $link."images-2/"); 
define('APP_TITLE',"Divvee Wireless"); 
$live = false;
?>