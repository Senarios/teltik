<?php if($live): ?>
	<link rel="stylesheet" href="<?=BASE; ?>styles.css?_=<?php echo date("Ymdhis");?>">
<?php else: ?>
	<link rel="stylesheet" href="<?=BASE; ?>styles.css?_=<?php echo date("Ymdhis");?>">
<?php endif; ?>